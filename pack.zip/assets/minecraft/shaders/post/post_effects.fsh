#version 330

#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:light.glsl>

uniform sampler2D InSampler;
uniform sampler2D RawScreenSampler;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

void main() {
    vec4 inTexel = texture(InSampler, texCoord);
    vec4 controlTexel = texture(RawScreenSampler, vec2(0.5, 0.5));
    vec4 subTexel = texture(RawScreenSampler, vec2(1.0, 0.5));

    float controlVal = round(controlTexel.r * 255.0);
    float subVal = round(subTexel.r * 255.0);

    vec4 result = inTexel;
    switch (int(controlVal)) {
        case 253: {
            float pixelSize = 4.0;
            vec2 pixelatedCoord = floor(texCoord * ScreenSize / pixelSize) * pixelSize / ScreenSize;
            vec4 pixelColor = texture(InSampler, pixelatedCoord);
            float gray = dot(pixelColor.rgb, vec3(0.299, 0.587, 0.114));
            gray = (gray - 0.5) * 1.2 + 0.5;
            gray = clamp(gray, 0.0, 1.0);
            result = vec4(gray, gray, gray, 1.0);
            break;
        }

        case 252: {
            float amount = 0.004;
            vec2 offset = vec2(amount, 0.0);
            float r = texture(InSampler, texCoord - offset).r;
            float g = texture(InSampler, texCoord).g;
            float b = texture(InSampler, texCoord + offset).b;
            vec3 color = vec3(r, g, b);
            vec2 uv = texCoord - 0.5;
            float vignette = smoothstep(0.85, 0.3, length(uv));
            color *= vignette;
            result = vec4(color, 1.0);
            break;
        }

        case 251: {
            vec3 color = result.rgb;
            color = (color - 0.5) * 1.15 + 0.5;
            float grainStrength = 0.035;
            float time = GameTime * 60.0;
            float noise = fract(sin(dot(texCoord + vec2(time * 0.3), vec2(12.9898, 78.233))) * 43758.5453);
            color += (noise - 0.5) * grainStrength;
            vec2 uv = texCoord - 0.5;
            float vignette = smoothstep(0.9, 0.25, length(uv));
            color *= vignette;
            result = vec4(color, result.a);
            break;
        }

        case 250: {
            float shakeIntensity = 0.012;
            float time = GameTime * 120.0;
            float shakeX = sin(time * 13.7) * shakeIntensity;
            float shakeY = cos(time * 17.3) * shakeIntensity * 0.6;
            vec2 shakenCoord = clamp(texCoord + vec2(shakeX, shakeY), 0.0, 1.0);
            result = vec4(texture(InSampler, shakenCoord).rgb, result.a);
            break;
        }

        case 249: {
            vec3 color = result.rgb;
            float letterbox = smoothstep(0.5, 0.0, abs(texCoord.y - 0.7));
            color *= letterbox;
            vec2 uv = texCoord - 0.5;
            float vignette = smoothstep(0.85, 0.35, length(uv));
            color *= vignette;
            result = vec4(color, result.a);
            break;
        }

        case 248: {
            float time = GameTime * 1000.0;
            float band = floor(texCoord.y * 85.0);
            float rand = fract(sin(band * 12.9898 + time * 4.2) * 43758.5453);
            vec2 offset = vec2(0.0);
            if (rand > 0.87) {
                offset.x = (fract(sin(band * 9.1 + time) * 98765.43) - 0.5) * 0.065;
            }
            result = vec4(texture(InSampler, texCoord + offset).rgb, result.a);
            break;
        }

        case 247: {
            vec3 color = result.rgb;
            float lum = dot(color, vec3(0.2126, 0.7152, 0.0722));
            float boost = 1.0 + pow(1.0 - lum, 1.8) * 3.8;
            color *= boost;
            color = mix(color, color * vec3(0.55, 1.35, 0.65), 0.38);
            float highlight = smoothstep(0.55, 0.92, lum);
            color += highlight * 0.12;
            result = vec4(color, result.a);
            break;
        }

        case 246: {
            float pixelSize = 4.0;
            vec2 pixelatedCoord = floor(texCoord * ScreenSize / pixelSize) * pixelSize / ScreenSize;
            vec4 pixelColor = texture(InSampler, pixelatedCoord);
            vec3 color = pixelColor.rgb;
            float lum = dot(color, vec3(0.2126, 0.7152, 0.0722));
            float boost = 1.0 + pow(1.0 - lum, 1.8) * 3.8;
            color *= boost;
            color = mix(color, color * vec3(0.55, 1.35, 0.65), 0.38);
            float highlight = smoothstep(0.55, 0.92, lum);
            color += highlight * 0.12;
            result = vec4(color, pixelColor.a);
            break;
        }

        case 245: {
            vec2 uv = texCoord;
            if (uv.y < 0.1 || uv.y > 0.9 || uv.x < 0.05 || uv.x > 0.95) {
                result = vec4(0.0, 0.0, 0.0, 1.0);
            } else {
                float pixelSize = 10.0;
                vec2 pixelatedCoord = floor(texCoord * ScreenSize / pixelSize) * pixelSize / ScreenSize;
                result = texture(InSampler, pixelatedCoord);
            }
            break;
        }

        case 244: {
            const float PincushionAmount = 0.02;
            const float CurvatureAmount  = 0.02;
            const float ScanlineAmount   = 0.8;
            const float ScanlineScale    = 1.0;
            const float ScanlineHeight   = 1.0;
            const float ScanlineBrightScale = 1.0;
            const float ScanlineOffset   = 0.0;
            const vec3 Floor = vec3(0.05);
            const vec3 Power = vec3(0.8);

            vec2 PinUnitCoord = texCoord * 2.0 - 1.0;
            float PincushionR2 = pow(length(PinUnitCoord), 2.0);
            vec2 PincushionCurve = PinUnitCoord * PincushionAmount * PincushionR2;

            vec2 ScanCoord = texCoord;
            ScanCoord *= 1.0 - PincushionAmount * 0.2;
            ScanCoord += PincushionAmount * 0.1;
            ScanCoord += PincushionCurve;

            if (ScanCoord.x < 0.0 || ScanCoord.y < 0.0 || ScanCoord.x > 1.0 || ScanCoord.y > 1.0) {
                result = vec4(0.0, 0.0, 0.0, 1.0);
            } else {
                float InnerSine = ScanCoord.y * ScreenSize.y * ScanlineScale * 0.25;
                float ScanBrightMod = sin(InnerSine * 3.1415926535 + ScanlineOffset * ScreenSize.y * 0.25);
                float ScanBrightness = mix(1.0,
                    (pow(ScanBrightMod * ScanBrightMod, ScanlineHeight) * ScanlineBrightScale + 1.0) * 0.5,
                    ScanlineAmount);
                vec3 color = texture(InSampler, ScanCoord).rgb * ScanBrightness;
                color = Floor + (1.0 - Floor) * color;
                color = pow(color, Power);
                result = vec4(color, 1.0);
            }
            break;
        }

        case 243: {
            float Radius = 10.0;
            vec4 c = texture(InSampler, texCoord);
            vec4 maxVal = c;
            for (float u = 0.0; u <= Radius; u += 1.0) {
                for (float v = 0.0; v <= Radius; v += 1.0) {
                    float dist = sqrt(u * u + v * v);
                    float weight = (dist / Radius > 1.0) ? 0.0 : 1.0;
                    vec4 s0 = texture(InSampler, texCoord + vec2(-u * oneTexel.x, -v * oneTexel.y));
                    vec4 s1 = texture(InSampler, texCoord + vec2( u * oneTexel.x,  v * oneTexel.y));
                    vec4 s2 = texture(InSampler, texCoord + vec2(-u * oneTexel.x,  v * oneTexel.y));
                    vec4 s3 = texture(InSampler, texCoord + vec2( u * oneTexel.x, -v * oneTexel.y));
                    vec4 o0 = max(s0, s1);
                    vec4 o1 = max(s2, s3);
                    vec4 tempMax = max(o0, o1);
                    maxVal = mix(maxVal, max(maxVal, tempMax), weight);
                }
            }
            result = vec4(maxVal.rgb, 1.0);
            break;
        }

        case 242: { // Clean Security Monitor
            vec2 uv = texCoord;
            vec3 color = texture(InSampler, uv).rgb;

            // Мягкая виньетка
            float vignette = smoothstep(0.95, 0.45, length(uv - 0.5));
            color *= mix(0.75, 1.0, vignette);

            // Очень лёгкий зеленоватый оттенок
            color = mix(color, color * vec3(0.82, 1.05, 0.88), 0.28);

            // Тонкие сканлайны
            float scan = sin(uv.y * ScreenSize.y * 1.1) * 0.5 + 0.975;
            color *= scan;

            // Аккуратная чёрная рамка
            float border = smoothstep(0.0, 0.025, uv.x) * smoothstep(0.0, 0.025, 1.0 - uv.x) *
                        smoothstep(0.0, 0.03, uv.y) * smoothstep(0.0, 0.03, 1.0 - uv.y);
            color *= border;

            // Лёгкое затемнение по углам
            color *= 0.92 + 0.08 * vignette;

            result = vec4(color, 1.0);
            break;
        }

        case 241: { // Soft Fat CRT
            vec2 uv = texCoord * 2.0 - 1.0;

            // Мягкое искажение
            float r2 = dot(uv, uv);
            uv *= 1.0 + r2 * 0.11;
            uv = uv * 0.5 + 0.5;

            if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) {
                result = vec4(0.0);
                break;
            }

            vec3 color = texture(InSampler, uv).rgb;

            // Очень мягкие сканлайны
            float scan = sin(uv.y * ScreenSize.y * 0.95) * 0.03 + 0.97;
            color *= scan;

            // Лёгкая виньетка
            float vignette = smoothstep(0.98, 0.5, length(uv - 0.5));
            color *= mix(0.8, 1.0, vignette);

            // Чуть тёплый оттенок
            color *= vec3(1.03, 0.99, 0.96);

            result = vec4(color, 1.0);
            break;
        }

        case 240: { // Flashlight
            vec2 uv = texCoord;
            vec3 color = texture(InSampler, uv).rgb;

            // Расстояние от центра экрана
            vec2 center = vec2(0.5);
            float dist = length(uv - center);

            // Основной луч фонарика (мягкий круг)
            float beam = smoothstep(0.48, 0.12, dist);

            // Внутренний более яркий круг
            float core = smoothstep(0.28, 0.05, dist);

            // Затемняем всё вокруг
            float darkness = mix(0.07, 1.0, beam);
            color *= darkness;

            // Делаем центр ярче
            color *= 1.0 + core * 0.55;

            // Лёгкий тёплый оттенок луча
            color = mix(color, color * vec3(1.08, 1.02, 0.92), beam * 0.4);

            // Совсем слабый шум внутри луча (пыль в свете)
            float noise = fract(sin(dot(uv * 40.0 + GameTime * 2.0, vec2(12.9898, 78.233))) * 43758.5453);
            color += (noise - 0.5) * 0.025 * beam;

            result = vec4(clamp(color, 0.0, 1.0), 1.0);
            break;
        }

        default:
            break;
    }

    switch (int(subVal)) {
        case 253: {
            vec3 color = result.rgb;
            color = (color - 0.5) * 1.15 + 0.5;
            float grainStrength = 0.035;
            float time = GameTime * 60.0;
            float noise = fract(sin(dot(texCoord + vec2(time * 0.3), vec2(12.9898, 78.233))) * 43758.5453);
            color += (noise - 0.5) * grainStrength;
            vec2 uv = texCoord - 0.5;
            float vignette = smoothstep(0.9, 0.25, length(uv));
            color *= vignette;
            result = vec4(color, result.a);
            break;
        }

        case 252: {
            vec3 color = result.rgb;
            float lum = dot(color, vec3(0.2126, 0.7152, 0.0722));
            float boost = 1.0 + pow(1.0 - lum, 1.8) * 3.8;
            color *= boost;
            color = mix(color, color * vec3(0.55, 1.35, 0.65), 0.38);
            float highlight = smoothstep(0.55, 0.92, lum);
            color += highlight * 0.12;
            result = vec4(color, result.a);
            break;
        }

        default:
            break;
    }

    fragColor = result;
}
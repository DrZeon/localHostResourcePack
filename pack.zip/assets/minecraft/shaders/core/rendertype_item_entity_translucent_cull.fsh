#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec2 texCoord0;
in vec2 texCoord1;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) * vertexColor * ColorModulator;
    if (color.a < 0.1) {
        discard;
    }

    ivec4 icolor = ivec4(round(texture(Sampler0, texCoord0)*255));
    switch (icolor.a) {
        case 254:
            color = vec4(texture(Sampler0, texCoord0));
            break;
        case 140:
            color = vec4(texture(Sampler0, texCoord0));
            break;
        case 120:
            color = vec4(texture(Sampler0, texCoord0));
            break;
        case 100:
            color = vec4(texture(Sampler0, texCoord0));
            break;
        case 80:
            color = vec4(texture(Sampler0, texCoord0));
            break;
        case 60:
            color = vec4(texture(Sampler0, texCoord0));
            break;
    }

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
